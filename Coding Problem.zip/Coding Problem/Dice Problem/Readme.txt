Features:

+ CommandLine Client Utility using executable jar.
+ All Error scenarios covered.
+ Used 'Random' functionality of Java JDK.
+ Run command : java -jar dice.jar n1Ds1+n2Ds2

Example: 
C:\Coding Problem\Dice Problem>java -jar dice.jar "32D4-1d3"
Only 4,6,8,10,12 supported ::: Invalid Parameters

C:\Coding Problem\Dice Problem>java -jar dice.jar "32D4-1d12"
36

C:\Coding Problem\Dice Problem>java -jar dice.jar "32D4 - 1d12"
39

C:\Coding Problem\Dice Problem>java -jar dice.jar "0D4 - 1d12"
0 times rolling of dice doesn't make sense ::: Invalid Parameters

C:\Coding Problem\Dice Problem>java -jar dice.jar "23n4 - 1d12"
Invalid, input : use only + or - as operators

Design Patterns and Principle used:

+ Proper breakdown of Functions. 
+ Single Responsiblity of S.O.L.I.D principles are used.