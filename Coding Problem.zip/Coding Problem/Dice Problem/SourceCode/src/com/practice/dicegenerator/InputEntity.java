package com.practice.dicegenerator;

public class InputEntity {
	
	private String input1;
	private String input2;
	private String operation;
	
	public InputEntity(String input1, String input2, String operation) {
		this.input1 = input1;
		this.input2 = input2;
		this.operation = operation;
	}

	public String getInput1() {
		return input1;
	}
	
	public void setInput1(String input1) {
		this.input1 = input1;
	}
	
	public String getInput2() {
		return input2;
	}
	
	public void setInput2(String input2) {
		this.input2 = input2;
	}
	
	public String getOperation() {
		return operation;
	}
	
	public void setOperation(String operation) {
		this.operation = operation;
	}
}
