package com.practice.dicegenerator;

import static com.practice.inputparser.ConstantParameters.ADDITION_OPERATOR;
import static com.practice.inputparser.ConstantParameters.LOWER_CASE_D;
import static com.practice.inputparser.ConstantParameters.UPPER_CASE_D;

import java.util.Random;

public class DiceRandGenerator {
	
	public Random randomGen;
	
	public DiceRandGenerator(){
		this.randomGen = new Random();
	}

	public int generateRandomResult(InputEntity inputEntity){
		
		String input1 = inputEntity.getInput1();
		String input2 = inputEntity.getInput2();
		String operation = inputEntity.getOperation();
		
		int inputResult1 = getRandomResultForGivenSet(input1);
		int inputResult2 = getRandomResultForGivenSet(input2);
		
		return performOperation(inputResult1,operation,inputResult2);
	}
	
	private int performOperation(int inputResult1, String operation, int inputResult2) {
		if(ADDITION_OPERATOR.equals(operation)){
			return inputResult1 + inputResult2;
		}else{
			if(inputResult1 > inputResult2){
				return inputResult1 - inputResult2;
			}else{
				return inputResult2 - inputResult1;
			}
		}
	}

	private int repeatRandomNtimes(int n,int s){
		int retVal = 0;
		
		for(int i=0;i<n;i++){
			retVal += randomGen.nextInt(s);
		}
		
		return retVal;
	}
	
	private int getRandomResultForGivenSet(String nDs){
		String[] nDsValue;
	
		if(nDs.contains(UPPER_CASE_D)){
			nDsValue = nDs.split("["+UPPER_CASE_D+"]");
		}else{
			nDsValue = nDs.split("["+LOWER_CASE_D+"]");
		}
		
		return repeatRandomNtimes(Integer.parseInt(nDsValue[0]),Integer.parseInt(nDsValue[1]));
	}
	

}
