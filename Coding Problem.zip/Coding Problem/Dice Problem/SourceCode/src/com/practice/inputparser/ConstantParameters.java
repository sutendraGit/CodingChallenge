package com.practice.inputparser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ConstantParameters {

	public static final List<Integer> AllowableDiceSides = new ArrayList<Integer>() {
		{
			add(4);
			add(6);
			add(8);
			add(10);
			add(12);
			add(20);
		}
	};
	
	public static final String ADDITION_OPERATOR = "+";
	public static final String SUBTRACTION_OPERATOR = "-";
	
	public static final String DEFAULT_ERROR_MSG = "Invalid Parameters";
	public static final String ZERO_TIME_DICE_ROLL_ERROR_MSG = "0 times rolling of dice doesn't make sense ::: Invalid Parameters";
	public static final String INVALID_SIDED_DICE_ERROR_MSG = "Only 4,6,8,10,12 supported ::: Invalid Parameters";
	
	public static final int DEFAULT_INVALID_PARAMETER_ERROR = -1;
	public static final int ZERO_TIME_DICE_ROLL_ERROR = -2;
	public static final int INVALID_SIDED_DICE_ERROR = -3;
	public static final int VALID_INPUT = 1;
	
	public static final String UPPER_CASE_D = "D";
	public static final String LOWER_CASE_D = "d";
	
	public static final Map<Integer,String> ERROR_MAPPER = new HashMap<Integer,String>() {
		{
			put(DEFAULT_INVALID_PARAMETER_ERROR,DEFAULT_ERROR_MSG);
			put(ZERO_TIME_DICE_ROLL_ERROR,ZERO_TIME_DICE_ROLL_ERROR_MSG);
			put(INVALID_SIDED_DICE_ERROR,INVALID_SIDED_DICE_ERROR_MSG);
		}
	};
}
