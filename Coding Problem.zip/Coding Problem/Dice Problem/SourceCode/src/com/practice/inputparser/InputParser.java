package com.practice.inputparser;

import static com.practice.inputparser.ConstantParameters.*;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.practice.dicegenerator.InputEntity;

public class InputParser {
	
	public InputEntity constructInputEntity(String input){
		InputEntity retInputEntity = null;
		String trimString = input.trim();
		String noSpaceString = trimString.replaceAll("\\s","");
		
		if (validateEntireInputStructure(noSpaceString)) {
			String[] inputStrings;
			if (noSpaceString.contains(ADDITION_OPERATOR)) {
				inputStrings = noSpaceString.split("["+ADDITION_OPERATOR+"]");
				if (validateBothInput(inputStrings)) {
					retInputEntity = new InputEntity(inputStrings[0], inputStrings[1], ADDITION_OPERATOR);
				}
			} else {
				inputStrings = noSpaceString.split("["+SUBTRACTION_OPERATOR+"]");
				if (validateBothInput(inputStrings)) {
					retInputEntity = new InputEntity(inputStrings[0], inputStrings[1], SUBTRACTION_OPERATOR);
				}
			}
		} else {
			System.out.println("Invalid, input : use only + or - as operators");
		}
		
		return retInputEntity;
	}

	
	private boolean validateEntireInputStructure(String input){
	    Pattern p = Pattern.compile("^[0-9]+[d|D][0-9]+[+|-][0-9]+[d|D][0-9]+$");
	    Matcher m = p.matcher(input);
	    boolean b = m.find();
		return b;
	}
	
	private boolean validateBothInput(String[] inputStrings){
		boolean retVal = false;
		int leftSideResult = validateOneInput(inputStrings[0]);
		int rightSideResult = validateOneInput(inputStrings[1]);
		
		if (leftSideResult < 0) {
			if (ERROR_MAPPER.get(leftSideResult) != null) {
				System.out.println(ERROR_MAPPER.get(leftSideResult));
			} else {
				System.out.println(DEFAULT_ERROR_MSG);
			}
		} else {
			if (rightSideResult < 0) {
				if (ERROR_MAPPER.get(rightSideResult) != null) {
					System.out.println(ERROR_MAPPER.get(rightSideResult));
				} else {
					System.out.println(DEFAULT_ERROR_MSG);
				}
			} else {
				retVal = true;
			}
		}

		return retVal;
	}
	
	private int validateOneInput(String input){
		int retVal = VALID_INPUT;
		String[] inputStrings;

		if(input.contains(UPPER_CASE_D)){
			inputStrings = input.split("["+UPPER_CASE_D+"]");
		}else{
			inputStrings = input.split("["+LOWER_CASE_D+"]");
		}
		
		int n = Integer.parseInt(inputStrings[0]);
		int s = Integer.parseInt(inputStrings[1]);
		
		if(n <= 0) {
			retVal = ZERO_TIME_DICE_ROLL_ERROR;
			return retVal;
		}
		
		if(!AllowableDiceSides.contains(s)){
			retVal = INVALID_SIDED_DICE_ERROR;
			return retVal;
		}
		
		return retVal;
		
	}

}
