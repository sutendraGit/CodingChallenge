package com.practice.client;

import com.practice.dicegenerator.DiceRandGenerator;
import com.practice.dicegenerator.InputEntity;
import com.practice.inputparser.InputParser;

public class MainClass {
	
	public static void main(String args[]){
		
		InputParser parser = new InputParser();
		InputEntity inputEntity = parser.constructInputEntity("32D4+ 12d20");
		int result = 0;
		
		if(inputEntity != null){
			result = new DiceRandGenerator().generateRandomResult(inputEntity);
			System.out.println(result);
		}
	}
}
