package com.practice.inmemfs.client;

import java.util.List;

import com.practice.inmemfs.cachingModule.FileLRUCache;
import com.practice.inmemfs.files.FileInstance;
import com.practice.inmemfs.filesystem.FileSystemInstance;

public class MainClass {
	
	public static void main(String[] args) {
	
		FileSystemInstance fileSystemInstance = new FileSystemInstance();
		FileInstance root = fileSystemInstance.intializeFileSystem();
		
		// TEST CASE 1:
		fileSystemInstance.createFile("/someFile",true);
		fileSystemInstance.createFile("/someDir", false);
		fileSystemInstance.createFile("/someDir2", false);
		fileSystemInstance.createFile("/someDir3", false);
		fileSystemInstance.createFile("/someDir3/someFile3", true);
		fileSystemInstance.createFile("/someDir3/someDir4", false);
		fileSystemInstance.createFile("/someDir/someFile2", true);
		
		//TEST CASE 2
		fileSystemInstance.parseDirectory(root);
		
		//TEST CASE 3
		FileInstance removedFile = fileSystemInstance.removeFile("/someFile");
		if(removedFile != null){
			System.out.println("File removed :::: "+ removedFile);
		}else{
			System.out.println("File removal failed");
		}
		fileSystemInstance.parseDirectory(root);
		
		
		//TEST CASE 4
		fileSystemInstance.removeFile("/");
		
		//TEST CASE 5
		FileLRUCache fileCache = fileSystemInstance.getCache();
		FileInstance fileInstance = fileCache.getLastAccessedFile();
		System.out.println("Last Accessed File in Cache :::: "+fileInstance);
		
		//TEST CASE 6
		List<FileInstance> cachedFiles = fileCache.getAllCacheFiles();
		System.out.println("All Cahced Files :");
		System.out.println(cachedFiles);
		
		
	}
}
