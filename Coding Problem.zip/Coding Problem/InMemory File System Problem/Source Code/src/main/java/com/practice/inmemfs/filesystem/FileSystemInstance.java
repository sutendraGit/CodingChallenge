package com.practice.inmemfs.filesystem;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.practice.inmemfs.cachingModule.FileLRUCache;
import com.practice.inmemfs.files.FileInstance;
import com.practice.inmemfs.files.IFile;
import com.practice.inmemfs.files.MemDirectory;
import com.practice.inmemfs.files.MemFile;

import sun.misc.LRUCache;

public class FileSystemInstance implements IFileSystem {
	
	private MemDirectory root;
	private FileLRUCache cache;

	/**
	 * FileSystemInstance holds the root of file system and manages CRUD operations on file instance.
	 */
	@Override
	public FileInstance intializeFileSystem() {
		root = (MemDirectory) createFile("/",false);
		cache = new FileLRUCache();
		return root;
	}
	

	/**
	 * @return IFile : Return the file instance of fileName else return null if File not found.
	 * @Param String : name of the file to be returned.
	 */
	@Override
	public FileInstance getFileObject(String absoluteFileName) {
		List<String> filePathList = prepareFilePathList(absoluteFileName);
		MemDirectory parentDirectory = traverseToParentDirectory(filePathList,root); 
		
		for(FileInstance fileInstance:parentDirectory.getChildFiles()){
			if(fileInstance.getFileName().contains(filePathList.get(filePathList.size()-1))){
				return fileInstance;
			}
		}
		
		return null;
	}

	/**
	 * @param String : name of the file.
	 * @param IFile  : parent file instance under which this file has to be created.
	 * @param boolean : Is it File isFile = true or Directory isFile = false.
	 */
	public IFile createFile(String absoluteFileName,boolean isFile) {
		FileInstance newFile;
		List<String> filePathList = prepareFilePathList(absoluteFileName);

		MemDirectory parentDirectory = traverseToParentDirectory(filePathList,root); 
		
		if(filePathList != null && parentDirectory != null){
			if(isFile){
				newFile = new MemFile(parentDirectory,absoluteFileName);
			}else{
				newFile = new MemDirectory(parentDirectory,absoluteFileName);
			}
			parentDirectory.getChildFiles().add(newFile);
			cache.put(newFile.getFileId(),newFile);
			return parentDirectory;
		}else{
			if(filePathList.size() == 1 && "/".equals(filePathList.get(0))){
				return new MemDirectory(null,"/");
			}else{
				System.out.println("File creation failed..");
				return null;	
			}
		}
	}

	private MemDirectory traverseToParentDirectory(List<String> filePathList,MemDirectory root) {
		MemDirectory parentDirectory =  null;
		
		if(root == null) return null;
		
		if(filePathList != null && filePathList.isEmpty()) return null;
		
		if(filePathList.size() == 1 && root.getFileName().equals("/")){
			return root;
		}
		
		if(filePathList.size() == 2){
			if(root.isFile() == false){
				return root;
			}else{
				return null;
			}
		}
		
		if(root.getFileName().equals(filePathList.get(0))){
			for(FileInstance fileInstance:root.getChildFiles()){
				if(fileInstance.getFileName().contains(filePathList.get(1))){
					filePathList.remove(0);
					parentDirectory = traverseToParentDirectory(filePathList,(MemDirectory)fileInstance);
					break;
				}
			}
			
		}
		return parentDirectory;
	}


	private List<String> prepareFilePathList(String absoluteFileName){
		
		  if (absoluteFileName == null || absoluteFileName.trim().isEmpty()) {
		         System.out.println("Incorrect format of fileName");
		         return null;
		     }
		     Pattern p = Pattern.compile("[^A-Za-z0-9//]");
		     Matcher m = p.matcher(absoluteFileName);
		     boolean b = m.find();
		     
		     String[] strArr = {"/"};
		     
			if (b == true) {
				System.out.println("Filepath Incorrect !!");
				return null;
			} else {
				if(!"/".equals(absoluteFileName)){
					strArr = absoluteFileName.split("[/]");
					List<String> retTempList =  Arrays.asList(strArr);
					List<String> retList = new ArrayList<>();
					retList.add("/");
					for(int i=1;i<=retTempList.size()-1;i++){
						retList.add(retTempList.get(i));
					}
					
					return retList;
				}else{
					return  Arrays.asList(strArr);
				}
				
			}
	}
	
	
	/**
	 * @return IFile : file instance which is removed from the File System.
	 */
	@Override
	public FileInstance removeFile(String absoluteFileName) {
		
		if("/".equals(absoluteFileName)){
			System.out.println("Removal not permitted");y
		}
		
		List<String> filePathList = prepareFilePathList(absoluteFileName);
		MemDirectory parentDirectory = traverseToParentDirectory(filePathList,root); 
		FileInstance removalFile = getFileObject(absoluteFileName);
		FileInstance retVal = null;
		
		if(filePathList != null && parentDirectory != null){
			for(FileInstance fileInstance:root.getChildFiles()){
				if(removalFile.equals(fileInstance)){
					if(parentDirectory.getChildFiles().remove(fileInstance)){
						retVal = fileInstance;
						return retVal;
					}
				}
			
			}
		}
		
		return retVal;
	}
	
	public void parseDirectory(FileInstance root){
		
		if(root == null) {
			return;
		}else{
			if(this.root.equals(root)){
				System.out.println("/");
			}
		}
		
		if (root.isFile()) {
			System.out.println(root.getFileName());
			return;
		} else {
			if (root instanceof MemDirectory) {
				List<FileInstance> childFiles = ((MemDirectory) root).getChildFiles();
				for (FileInstance fileInstance : childFiles) {
					System.out.println(fileInstance.getFileName() + " :::: " + (fileInstance.isFile()? "file" : "dir"));
					if (!fileInstance.isFile()) {
						parseDirectory(fileInstance);
					}
				}
			}
		}
	}


	public MemDirectory getRoot() {
		return root;
	}


	public void setRoot(MemDirectory root) {
		this.root = root;
	}


	public FileLRUCache getCache() {
		return cache;
	}


	public void setCache(FileLRUCache cache) {
		this.cache = cache;
	}

}
