package com.practice.inmemfs.files;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MemDirectory extends FileInstance{

	private List<FileInstance> childFiles;
	
	public MemDirectory(IFile parentDir, String fileName) {
		super(parentDir, fileName,false);
		childFiles = new ArrayList<>();
	}

	/**
	 * Lists all files and directory in non recursive way.
	 */
	public void parseDirectory(){
		Iterator<FileInstance>  fileIterator = childFiles.iterator();
		FileInstance fileInstance = null;
		while(fileIterator.hasNext()){
			fileInstance = (FileInstance) fileIterator.next();
			System.out.println(fileInstance);
		}
	}
	
	/**
	 * Prints the this directory and its child file and directory in 'Tree structure' recursive way.
	 */
	public void printTreeStructure(){
		Iterator<FileInstance>  fileIterator = childFiles.iterator();
		FileInstance fileInstance = null;
		while(fileIterator.hasNext()){
			fileInstance = fileIterator.next();
			if(!fileInstance.isFile()){
				System.out.println();
				System.out.println(" ");
				MemDirectory childDirectory = (MemDirectory) fileInstance;
				childDirectory.printTreeStructure();
			}else{
				System.out.println(fileInstance);
			}
		}
		
	}
	
	
	/**
	 * Adds the file under this directory structure. 
	 * @param String : name of the file
	 * @return IFile : return this object as it form the file under which file with fileName is added.
	 */
	public FileInstance addFile(FileInstance fileInstance){
		childFiles.add(fileInstance);
		return this;
		
	}
	
	/**
	 * Removes the given file under this file directory structure.
	 * @param IFile : file to be removed.
	 * @return IFile : return the file instance that is being removed under this file directory structure.
	 */
	public FileInstance removeFile(FileInstance fileInstance){
		if(childFiles.contains(fileInstance)){
			if(childFiles.remove(fileInstance)){
				return fileInstance;
			}
		}
		return null;
	}

	public List<FileInstance> getChildFiles() {
		return childFiles;
	}

}
