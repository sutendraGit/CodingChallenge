package com.practice.inmemfs.files;

public class MemFile extends FileInstance {

	private String content;
	
	public MemFile(IFile parentDir, String fileName) {
		super(parentDir, fileName,true);
	}

	
	/**
	 * Retrieve File content as Array of Bytes.
	 * @return byte[] fileContent
	 */
	public byte[] getFileContentInBytes() {
		return content.getBytes();
	}
	
	/**
	 * Retrieve File content as String.
	 * @return String fileContent
	 */
	public String getFileContentInString(){
		return content;
	}
	
	/**
	 * Write file content to File in bytes.
	 * @param byte[] : Takes content as byte array as input and stores the content in string format.
	 * @return int   : Size of the string - as file content size.
	 */
	public int writeFileContent(byte[] content) {
		this.content += content.toString();
		return 0;
	}
	
	/**
	 * Append the content to this file.
	 * @param content
	 */
	public void setContent(byte[] content) {
		this.content = content.toString();
	}
	

	
}
