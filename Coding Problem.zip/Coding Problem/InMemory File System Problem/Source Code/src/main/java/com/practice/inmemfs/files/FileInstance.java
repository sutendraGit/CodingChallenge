package com.practice.inmemfs.files;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

public abstract class FileInstance implements IFile,Serializable {
	
	public static final long serialVersionUID = 92L;
	
	private IFile parentDir;
	private String fileName;
	private Date lastAccessed;
	private boolean isFile;
	private String fileId;


	public FileInstance(IFile parentDir, String fileName, boolean isFile) {
		this.parentDir = parentDir;
		this.fileName = fileName;
		this.isFile = isFile;
		this.fileId = UUID.randomUUID().toString();
	}

	/**
	 * Writes File content to localDisk - for file persistence and for later usage.
	 * 
	 * @param IFile : In memory file object whose content is needed to be persisted.
	 * @return File : Java File object, where the content and file metadata is persisted. 
	 */
	@Override
	public File flushToDisk() {
		File file = new File("DiskFile-"+this.getFileName());
		ObjectOutputStream oStream;
		
		try {
			oStream = new ObjectOutputStream(new FileOutputStream(file));
			oStream.writeObject(this);
			
			oStream.flush();
			oStream.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return file;
	}

	public IFile getParentDir() {
		return parentDir;
	}

	public String getFileName() {
		return fileName;
	}

	public boolean isFile() {
		return isFile;
	}

	public Date getLastAccessed() {
		return lastAccessed;
	}

	public void setLastAccessed(Date lastAccessed) {
		this.lastAccessed = lastAccessed;
	}

	@Override
	public String toString() {
		if(isFile){
			return "[" +fileName + "::: File]";
		}else{
			return "[" +fileName + "::: Dir]";
		}
		
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fileId == null) ? 0 : fileId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FileInstance other = (FileInstance) obj;
		if (fileId == null) {
			if (other.fileId != null)
				return false;
		} else if (!fileId.equals(other.fileId))
			return false;
		return true;
	}

	public String getFileId() {
		return fileId;
	}


	
	

}
