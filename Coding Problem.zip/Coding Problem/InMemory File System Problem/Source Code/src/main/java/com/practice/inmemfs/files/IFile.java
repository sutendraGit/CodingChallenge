package com.practice.inmemfs.files;

import java.io.File;

public interface IFile {
	
	public File flushToDisk();
}
