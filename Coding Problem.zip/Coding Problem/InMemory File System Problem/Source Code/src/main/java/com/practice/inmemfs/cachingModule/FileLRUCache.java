package com.practice.inmemfs.cachingModule;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;

import com.practice.inmemfs.files.FileInstance;

public class FileLRUCache extends LinkedHashMap<String,FileInstance>{
	private static final long serialVersionUID = 1L;
	private static final int CACHE_SIZE = 2;
	private static final float LOAD_FACTOR = 0.75f;
	
	public FileLRUCache(){
		super(CACHE_SIZE,LOAD_FACTOR,true);
	}
	
	@Override
	protected boolean removeEldestEntry(java.util.Map.Entry<String, FileInstance> eldest) {
		return size() > CACHE_SIZE;
	}
	
	public FileInstance getLastAccessedFile(){
		ListIterator<FileInstance> iterator = getAllCacheFiles().listIterator(getAllCacheFiles().size());
		if(iterator.hasPrevious()){
			return iterator.previous();
		}else{
			System.out.println("Cache Empty");
			return null;
		}
	}

	public List<FileInstance> getAllCacheFiles(){
		return new ArrayList(values());
	}

}
