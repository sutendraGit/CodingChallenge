package com.practice.inmemfs.filesystem;

import com.practice.inmemfs.files.FileInstance;
import com.practice.inmemfs.files.IFile;

public interface IFileSystem {
	
	public FileInstance intializeFileSystem();
	public FileInstance getFileObject(String fileName);
	public IFile createFile(String absoluteFileName,boolean isFile);
	public IFile removeFile(String absoluteFileName);
}
