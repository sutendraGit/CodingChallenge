Features Of In Memory FileSystem:

+ Create File and Directory.
+ Delete File and Directory.
+ List the Files within the Directory.
+ Write to File in bytes format.
+ Read from File in bytes format.
+ Contents are stored in String format.
+ Get the fast and easy retrieval of latest 2 file access or creation using LRU Cache.

Assumption:

+ Creation of Files - on using only Absolute File Name.
+ Special Characters other than alpha numeric contents and '/' are not allowed.
+ '/' used for directory structure.
+ Did not cover Junit test case.

Design Patterns and Principle used:

+ 'Composite Pattern' used to form the FileSystem and bring in the Tree Structure.
+ 'Factory Pattern' used to get the file object - given the file name as input.
+  Single Responsiblity and Interface Segreggation principles of S.O.L.I.D principles are used.

